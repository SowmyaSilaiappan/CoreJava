package CJ.Step3;

import java.io.BufferedReader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;



import java.util.List;
import java.util.Scanner;



public class ReadCSV {

	private static final int  ID_INDEX=0;
	private static final int season_INDEX=1;
	private static final int city_INDEX=2;
	private static final int date_INDEX=3;
	private static final int team1_INDEX=4;
	private static final int team2_INDEX=5;
	private static final int toss_winner_INDEX=6;
	private static final int toss_dicision_INDEX=7;
	private static final int result_INDEX=8;
	private static final int dl_applied_INDEX=9;
	private static final int winner_INDEX=10;
	private static final int win_by_runs_INDEX=11;
	private static final int win_by_wickets_INDEX=12;
	private static final int player_of_match_INDEX=13;
	private static final int venue_INDEX=14;
	private static final int umpire1_INDEX=15;
	private static final int umpire2_INDEX=16;
	private static final int umpire3_INDEX=17;
	
	
    // CSV file path - C:\\Users\\ka377219\\Desktop\\step3.csv
	public static void main(String[] args) {
		
		System.out.println("Enter File name");
		
	  Scanner scanner = new Scanner(System.in);
	  String file =  scanner.nextLine();
	  scanner.close();
		
		ReadCSV csv = new ReadCSV();
		csv.readCSVFile(file);
	    
	}

	public void readCSVFile(String filePath) {
		try {
			List <CSVHeaders>dataList = new ArrayList<>();
			
			FileReader pth = new FileReader(filePath);
			BufferedReader br = new BufferedReader(pth);
			CSVHeaders csvHeaders = null;
			
			
			
			while(br.readLine() != null){
				String [] mat1 = br.readLine().split("/n");
				String [] mat = br.readLine().split(",");
				
				if(mat.length>0)
				{
					 csvHeaders = new CSVHeaders(Integer.parseInt(mat[ID_INDEX]), 
							Integer.parseInt(mat[season_INDEX]),mat[city_INDEX],mat[date_INDEX], 
							mat[team1_INDEX], mat[team2_INDEX], mat[toss_winner_INDEX],
							mat[toss_dicision_INDEX],mat[result_INDEX],Integer.parseInt(mat[dl_applied_INDEX]),
							mat[winner_INDEX],Integer.parseInt(mat[win_by_runs_INDEX]),
							Integer.parseInt(mat[win_by_wickets_INDEX]), mat[player_of_match_INDEX], mat[venue_INDEX], 
							mat[umpire1_INDEX], mat[umpire2_INDEX], mat[umpire3_INDEX]);
							dataList.add(csvHeaders);			
				}
			}
			
			System.out.println("output------");
			for (int i = 0; i <csvHeaders.output().size(); i++) {
				System.out.println(	csvHeaders.output().get(i));
			}
	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
