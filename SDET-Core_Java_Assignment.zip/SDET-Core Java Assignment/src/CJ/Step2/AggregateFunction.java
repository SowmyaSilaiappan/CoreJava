package CJ.Step2;

public class AggregateFunction {

	private String field;
	private String result;
	private String function;
	private int aggregateFieldIndex;

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getFunction()
	{
		return function;
	}

	public void setFunction(String function)
	{
		this.function = function;
	}

	public int getAggregateFieldIndex() 
	{
		return aggregateFieldIndex;
	}

	public void setAggregateFieldIndex(int aggregateFieldIndex)
	{
		this.aggregateFieldIndex = aggregateFieldIndex;
	}

}
