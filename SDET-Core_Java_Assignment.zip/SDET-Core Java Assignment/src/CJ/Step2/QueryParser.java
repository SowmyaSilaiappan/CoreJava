package CJ.Step2;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class QueryParser {

	public QueryParameter parseQuery(String queryString) {

		QueryParameter para = new QueryParameter();
		queryString = queryString.toLowerCase();

		para.setQueryString(queryString);
		para.setBaseQuery(getBaseQuery(queryString));
		para.setFile(getFile(queryString));
		para.setFields(getFields(queryString));
		para.setRestrictions(getConditions(queryString));
		para.setAggregateListFunctions(getAggregateListFunctions(queryString));
		para.setAggregateFunctions(getAggregateFunctionsArray(queryString));
		para.setOrderByFields(getFields(queryString));
		para.setGroupByFields(getGroupByFields(queryString));
		
		return para;

	}

	// baseQuery 
	public String getBaseQuery(String queryString) {
		String[] a=queryString.split(" ");
		
		String n="";
		
		for(int i=0;i<a.length;i++)
		{
			
			if(a[i].equals("where"))
			{
				break;
			}
			n=n+a[i]+" ";
			
		}
		return n;

	}

	// filename
	public String getFile(String queryString) {

		String fileName = queryString.split("from")[1].split("\\s+")[1];
		return fileName;
	}
//Fields
	public List<String> getFields(String queryString) {
		String[] requiredfields = queryString.split("select")[1].trim().split("from")[0].split("[\\s,]+");
		return Arrays.asList(requiredfields);

	}

	public Restriction[] getConditions(String queryString) {
		queryString = queryString.toLowerCase();
		String[] nameAndValue;
		String propertyName, propertyValue, conditionalOperator;

		int counter = 0;
		if (queryString.contains("where")) {
			String whereCondition = queryString.split("order by")[0].trim().split("group by")[0].trim()
					.split("where")[1].trim();
			String[] conditions = whereCondition.split("\\s+and\\s+|\\s+or\\s+");
			Restriction[] arrayrestric = new Restriction[conditions.length];
		

			for (String condition : conditions) 
			{
				Restriction restric = new Restriction();
				
				nameAndValue = condition.split("<=|>=|!=|=|<|>");
				propertyName = nameAndValue[0].trim();
				propertyValue = nameAndValue[1].trim();
				conditionalOperator = condition.split(propertyName)[1].trim().split(propertyValue)[0].trim();

				restric.setCondition(conditionalOperator);
				restric.setPropertyName(propertyName);
				restric.setPropertyValue(propertyValue);

				arrayrestric[counter] = restric;
				counter++;
			}
			return arrayrestric;
		} else {
			return null;
		}
	}

	public List<AggregateFunction> getAggregateListFunctions(String queryString) {
		String aggregateName, aggregateField;
		List<AggregateFunction> aggregateFunctionsList = new ArrayList<AggregateFunction>();
		int counter = 0;
		if (queryString.contains("count") || queryString.contains("sum") || queryString.contains("min")
				|| queryString.contains("max") || queryString.contains("avg")) {

			String[] aggregateFunctions = queryString.split("select")[1].trim().split("from")[0].trim().split(",");

			
			for (String function : aggregateFunctions) {
				AggregateFunction aggregateFunction = new AggregateFunction();

				aggregateName = function.split("\\(")[0].trim();
				aggregateField = function.split("\\(")[1].trim().split("\\)")[0].trim();

				aggregateFunction.setAggregateFieldIndex(counter);
				aggregateFunction.setField(aggregateField);
				aggregateFunction.setFunction(aggregateName);
				aggregateFunctionsList.add(aggregateFunction);
				counter++;

			}
			return aggregateFunctionsList;
		} else {
			return null;
		}
	}
	

	
	public AggregateFunction [] getAggregateFunctionsArray(String queryString) {
		String aggregateName, aggregateField;
		
		int counter = 0;
		if (queryString.contains("count") || queryString.contains("sum") || queryString.contains("min")
				|| queryString.contains("max") || queryString.contains("avg")) {

			String[] aggregateFunctions = queryString.split("select")[1].trim().split("from")[0].trim().split(",");
			AggregateFunction [] arrayOfAggregateFun = new AggregateFunction[aggregateFunctions.length];

			
			for (String function : aggregateFunctions) {
				AggregateFunction aggregateFunction = new AggregateFunction();

				aggregateName = function.split("\\(")[0].trim();
				aggregateField = function.split("\\(")[1].trim().split("\\)")[0].trim();

				aggregateFunction.setAggregateFieldIndex(counter);
				aggregateFunction.setField(aggregateField);
				aggregateFunction.setFunction(aggregateName);
				arrayOfAggregateFun[counter] = aggregateFunction;
				counter++;

			}
			return arrayOfAggregateFun;
		} else {
			return null;
		}
	}
	
	
	
	// get order by fields if order by clause exists
	public List<String> getOrderByFields(String queryString) {
		
		if(queryString.contains("order by"))
		{
			
			String[] orderByField=queryString.split("order by")[1].trim().split("[\\s,]+");
			return Arrays.asList(orderByField);
		}
		else
		{
			return null;
		}
	}
	
	// get group by fields if group by clause exists
	public List<String> getGroupByFields(String queryString) {
		
		if(queryString.contains("group by"))
		{
			
			String[] groupByField=queryString.split("group by")[1].trim().split("[\\s,]+");
			return Arrays.asList(groupByField);
		}
		else
		{
			return null;
		}
}

	public void printrestrics(Restriction[] restrics, QueryParameter parameter) {

		int count = 1;

		for (Restriction res : parameter.getRestrictions()) {
			System.out.println("Condition " + count + " :");
			System.out.println("variable : " + res.getPropertyName());
			System.out.println("operator : " + res.getCondition());
			System.out.println("value : " + res.getPropertyValue());
			count++;
		}

		System.out.println("-------------------------------");
	}

	public void printAggregateFunctionsList(List<AggregateFunction> list, QueryParameter parameter) {

		for (AggregateFunction aggregateFunction : list) {

			System.out.println("AggregateFieldIndex " + aggregateFunction.getAggregateFieldIndex() + " :");
			System.out.println("Aggregate Name : " + aggregateFunction.getFunction());
			System.out.println("Aggregate Field : " + aggregateFunction.getField());
			System.out.println("Aggregate Result : " + aggregateFunction.getResult());
		}

		System.out.println("-------------------------------");
	}
	
	
	
	public void printAggregateFunctionsArray(AggregateFunction[] array, QueryParameter parameter) {

		for (AggregateFunction aggregateFunction : array) {

			System.out.println("AggregateFieldIndex " + aggregateFunction.getAggregateFieldIndex() + " :");
			System.out.println("Aggregate Name : " + aggregateFunction.getFunction());
			System.out.println("Aggregate Field : " + aggregateFunction.getField());
			System.out.println("Aggregate Result : " + aggregateFunction.getResult());
		}

		System.out.println("-------------------------------");
	}

	

	public static void main(String[] args) {

		QueryParser parser = new QueryParser();
		QueryParameter para;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the query : ");
		String queryString = scanner.nextLine();
		para = parser.parseQuery(queryString);
		scanner.close();
		
		System.out.println("BASE QUERY: " + para.getBaseQuery());

		System.out.println("QUERY STRING: " + para.getQueryString());
		
		System.out.println("QUERY File: " + para.getFile());

		System.out.println("QUERY FIELDS: " + para.getFields());

		if (para.getRestrictions() != null) 
		{
			System.out.println("Restrics");
			parser.printrestrics(para.getRestrictions(), para);
		}

		if (para.getAggregateListFunctions() != null) 
		{
			System.out.println("Aggregate Functions in List");
			parser.printAggregateFunctionsList(para.getAggregateListFunctions(), para);
		}
		
		if (para.getAggregateFunctions() != null) 
		{
			System.out.println("Aggregate Functions in Array");
			parser.printAggregateFunctionsArray(para.getAggregateFunctions(), para);
		}
		
		if (para.getOrderByFields() != null) 
		{
			System.out.println("ORDER BY: "+para.getOrderByFields().get(0));
		}
		
		if (para.getGroupByFields() != null) 
		{
			System.out.println("GROUP BY: "+para.getGroupByFields().get(0));
		}
		

	}

}
