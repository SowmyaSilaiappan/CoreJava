package CJ.Step1;

public class Test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String x ="select * from ipl.csv where season > 2014 and city = 'Bangalore'" ;
		
		String[] a=x.split(" ");
		
		String n="";
		
		for(int i=0;i<a.length;i++)
		{
			
			if(a[i].equals("where"))
			{
				break;
			}
			n=n+a[i]+" ";
			
		}
		System.out.println(n);

	}

}
