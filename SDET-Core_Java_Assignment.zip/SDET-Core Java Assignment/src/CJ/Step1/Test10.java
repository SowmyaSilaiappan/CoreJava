package CJ.Step1;

public class Test10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a= "select avg(win_by_wickets),min(win_by_runs) from ipl.csv ";
		
		//Average,Maximum,Minimum,Sum,Count
		String h="";
		String c="";
		String d="";
		String e="";
		String f="";
		String g="";
		
		String[] b=a.split(" ");
		for(int i=0;i<b.length;i++)
		{
			h=h+b[i]+",";
		}
		System.out.println(h);
		
		String[] z=h.split(",");
		for(int i=0;i<z.length;i++)
		{
			if((z[i].substring(0,3).equals("avg")))
			{
				c=c+z[i]+"";
			}
			if((z[i].substring(0,3).equals("min")))
			{
				d=d+z[i]+"";
			}
			if((z[i].substring(0,3).equals("max")))
			{
				e=e+z[i]+"";
			}
			if((z[i].substring(0,3).equals("sum")))
			{
				f=f+z[i]+"";
			}
			if((z[i].substring(0,4).equals("coun")))
			{
				g=g+z[i]+"";
			}
		}
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		System.out.println(f);
		System.out.println(g);

	}

}
