package CJ.Step1;

public class Test6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String a=  "select season,winner,player_match from ipl.csv where season > 2014 and city ='Bangalore' or date > '31-12-2014'";
		
		String[] b=a.split(" ");
		String c="";String d="";String e="";String f="";
		for(int i=0;i<b.length;i++)
		{
			if(b[i].equals("and"))
			{
				c=b[i]+"";
			}
			if(b[i].equals("or"))
			{
				d=b[i]+"";
			}
			if(b[i].equals("not"))
			{
				e=b[i]+"";
			}
		}
	System.out.println();
	System.out.println(c);
	System.out.println(d);
	System.out.println(e);

	}

}
