package CJ.Step1;

public class Test7 
{
	
	
	//Extract the selected fields/information from the given query
	public static void main(String[] args) {
		
	
	String a="select city,winner,player_match from ipl.csv where season > 2014 and city = 'Bangalore'";
	
	String b[]=a.split (" ");
	
	String c="";
	for(int i=0;i<b.length;i++)
	{
		if(b[i].equals("select")||b[i].equals("from"))
		{
			
			if(b[i].equals("from"))
			{
				break;
			}
			c=c+b[i+1]+" ";
			
		}
	}
	String d=c+"";
	String[] e=d.split(",");
	String f="";
	System.out.println();
	for(int i=0;i<e.length;i++)
	{
		System.out.println(e[i]);
	}
	//System.out.println(c);

}
}
