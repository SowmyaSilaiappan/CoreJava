/**
 * 
 */
/**
 * @author KA377219
 *
 */
package CJ.Step1;
public class Test1{
	public static void main(String[] args) {
		
		//Input String :      select * from ipl.csv where season > 2014 and city = 'Bangalore'
		
		String x ="select * from ipl.csv where season > 2014 and city = 'Bangalore'" ;
		
		String a=x.toLowerCase();
		
		String[] b=a.split(" ");
		
		for(int i=0;i<b.length;i++)
		{
			System.out.println(b[i]);
		}
		//System.out.println(a);
	}
	
	

}

