package CJ.Step1;

public class Test4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String x ="select * from ipl.csv where season > 2014 and city = 'Bangalore'" ;
		
		String reverse="";
		
		String[] b=x.split(" ");
		
		for(int i=0;i<b.length;i++)
		{
			reverse = reverse + b[b.length-1-i]+" ";
		}
			
		//System.out.println(reverse);
		
		String a=reverse.toLowerCase();
		
		String[] z=a.split(" ");
		
		String k="";
		
		for(int i=0;i<z.length;i++)
		{
			if(z[i].equals("where"))
			{
				break;
			}
			k=k+z[i]+" ";
		}
		//System.out.println(k);
		
		String[] c=k.split(" ");
		
		String h="";
		
		for(int i=0;i<c.length;i++)
		{
			h = h + c[c.length-1-i]+" ";
		}
		
		
		System.out.println(h);
		
	}

}
