package CJ.Step1;

public class Test9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
String a= "select team1, sum(win_by_runs) from ipl.csv where season > 2016 and city= 'Bangalore' group by team1";
		
		String[] b=a.split(" ");
		String d="";
		
		for(int i=0;i<b.length;i++)
		{
			
			d=d+b[i]+"";
		}
		//System.out.println(d);
		String c="";
		int r=0;
		for(int i=0;i<b.length;i++)
		{
			if(b[i].equals("group"))
			{
				r=i;
			}
		}
		String m="";
		//System.out.println(r);
		for(int i=0;i<b.length;i++)
		{
			if(i<=r || b[i].equals("by"))
			{
				
					c=c+b[i+1]+"";
			}
			else
			{
				m=m+b[i]+" ";
			}
		}
		
		System.out.println(m);
	}


	}


