package CJ.Step1;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Input String :      select * from ipl.csv where season > 2014 and city = 'Bangalore'
		
				String x ="select * from ipl.csv where season > 2014 and city = 'Bangalore'" ;
				
				String fileName = x.split("from")[1].split("\\s+")[1];
				
				System.out.println(fileName+"");

	}

}
